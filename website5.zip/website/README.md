# Social Media Website 
Multiple users functionality, Interactive Design, offline-storage compatible,html css js based socail media website.






## Technology used 
- HTML
- CSS
- JAVASCRIPT
- JQUERY
- Icons used from Bootstrap.

## Features

- Multiple User accounts
- User Validation. 
- Interactive UI design.
- Uploading posts from a particular account. 
- All posts can be seen by any user account.
- User can like each other's posts which are counted.
- User can add captions to their posts while uploading.


## Installation

Ta-Da ! 
You don't have to worry about anything . 
we have just used html css js, 
so you don't have to install another packeges.

you can clone the project using
```
git clone 
```
.

```sh
127.0.0.1:5500
```

if you encounter any problems, please firsty clear your local storage and session, storage .

## License

MIT

**Free Software, Hell Yeah!**

[//]: # (These are reference links used in the body of this note and get stripped out when the markdown processor does its job. http://stackoverflow.com/questions/4823468/store-comments-in-markdown-syntax)

[attendance]: 
[Bootstrap]: 
[public repository]: 